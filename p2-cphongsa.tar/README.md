# CPSC-351-P2
CPSC 351 PROJECT TWO

**Group Members**

Christopher Phongsa - cphongsa@csu.fullerton.edu

Jared Castaneda - jaredcast97@gmail.com

Juan Toledo - toledojuan73@gmail.com

Efrain Lozada Trujillo - efrainlozada84@csu.fullerton.edu


**Programming Language used:**

C++


# How to execute the program
1. Open a working terminal.
2. Type 'make' in the terminal.
3. Type './main'
4. You wil be prompted to enter a memory size.
5. After you have entered a memory size, you will be prompted to enter a page size.
6. Futhermore, select a file name that you wish to open.
7. The terminal will then compile and display each process's arrival, admission to the main memory, and completion time.
8. Finish


# Teamwork Distribution
Christopher Phongsa - Worked on the Memory Manager and the MAKEFILE

Jared Castaneda - Worked on initializing input and wait queues, reading processes in from files, and memory manager

Juan Toledo - Typed the function to display the memory map output

Efrain - Worked on the design and documentation of the project. Edited readme.
